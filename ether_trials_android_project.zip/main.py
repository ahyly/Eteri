__version__ = '5.6.0'
import os, shutil, time
from functools import partial
from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.metrics import dp, sp
from kivy.uix.widget import Widget
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.image import Image
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.progressbar import ProgressBar
from kivy.uix.popup import Popup
from kivy.graphics import Color, Rectangle, RoundedRectangle, Line
from kivy.animation import Animation
from game_core import *

BG=(.035,.055,.085,1); PANEL=(.055,.085,.12,.96); CARD=(.075,.11,.16,.96); TEXT=(.94,.94,.92,1); MUTED=(.62,.69,.76,1); GOLD=(.92,.70,.30,1); ACCENT=(.40,.70,1,1); GREEN=(.35,.78,.48,1); RED=(.90,.34,.34,1); PURPLE=(.72,.58,1,1)

class BgBox(BoxLayout):
    def __init__(self,bg=PANEL,border=(.24,.31,.40,1),radius=8,**kw):
        super().__init__(**kw); self._bg=bg; self._border=border; self._radius=radius
        with self.canvas.before:
            self.c=Color(*bg); self.r=RoundedRectangle(pos=self.pos,size=self.size,radius=[radius]); self.bc=Color(*border); self.l=Line(rounded_rectangle=(self.x,self.y,self.width,self.height,radius),width=1.1)
        self.bind(pos=self._sync,size=self._sync)
    def _sync(self,*a): self.r.pos=self.pos; self.r.size=self.size; self.l.rounded_rectangle=(self.x,self.y,self.width,self.height,self._radius)

class FitLabel(Label):
    def __init__(self,**kw):
        kw.setdefault('color',TEXT); kw.setdefault('halign','left'); kw.setdefault('valign','middle'); kw.setdefault('font_size',sp(16)); super().__init__(**kw); self.bind(size=lambda *_:setattr(self,'text_size',(self.width,None)))

class EnemyCard(Button):
    def __init__(self,enemy,app,**kw):
        self.enemy=enemy; self.app_ref=app
        super().__init__(background_normal='',background_down='',background_color=(0,0,0,0),**kw)
        self.layout=FloatLayout(); self.add_widget(self.layout)
        self.img=Image(source=app.core.enemy_asset(enemy),allow_stretch=True,keep_ratio=True,size_hint=(.72,.66),pos_hint={'center_x':.5,'top':.96}); self.layout.add_widget(self.img)
        self.name_lbl=Label(text=enemy.name,font_size=sp(13),bold=True,color=TEXT,size_hint=(.95,.13),pos_hint={'center_x':.5,'y':.17},halign='center'); self.layout.add_widget(self.name_lbl)
        self.hp_lbl=Label(font_size=sp(12),color=GREEN,size_hint=(.95,.12),pos_hint={'center_x':.5,'y':.05}); self.layout.add_widget(self.hp_lbl)
        with self.canvas.before:
            self.c=Color(*CARD); self.rect=RoundedRectangle(pos=self.pos,size=self.size,radius=[8]); self.oc=Color(.22,.28,.36,1); self.line=Line(rounded_rectangle=(self.x,self.y,self.width,self.height,8),width=1.2)
        self.bind(pos=self._sync,size=self._sync,on_release=self.choose); self.refresh()
    def _sync(self,*a): self.rect.pos=self.pos; self.rect.size=self.size; self.line.rounded_rectangle=(self.x,self.y,self.width,self.height,8); self.layout.pos=self.pos; self.layout.size=self.size
    def choose(self,*a): self.app_ref.core.select_enemy(self.enemy); self.app_ref.refresh_combat()
    def refresh(self):
        e=self.enemy; self.hp_lbl.text=f'❤ {e.hp}/{e.max_hp}' if e.hp>0 else '☠ ПЕРЕМОЖЕНИЙ'; selected=(self.app_ref.core.combat and self.app_ref.core.combat.get('target') is e and e.hp>0)
        self.oc.rgba=GOLD if selected else ((.18,.22,.26,1) if e.hp<=0 else (.22,.28,.36,1)); self.c.rgba=(.10,.12,.15,.72) if e.hp<=0 else CARD; self.img.opacity=.30 if e.hp<=0 else 1
    def flash(self,color=RED):
        old=self.img.color; self.img.color=color; Animation(color=(1,1,1,1),duration=.18).start(self.img)

class EtherTrialsApp(App):
    title='Ефірні Випробування'
    def build(self):
        Window.clearcolor=BG
        try:Window.fullscreen=True
        except Exception:pass
        self.root_box=FloatLayout(); self.core=GameCore(self.user_data_dir); self.combat_ev=None; self.enemy_cards=[]; self.copy_default_saves(); self.start_screen(); return self.root_box
    def copy_default_saves(self):
        base=os.path.dirname(os.path.abspath(__file__)); src=os.path.join(base,'default_saves')
        for fn in ('save_mage.json','save_warrior.json','save_monk.json'):
            dst=os.path.join(self.user_data_dir,fn)
            if not os.path.exists(dst) and os.path.exists(os.path.join(src,fn)):
                shutil.copy2(os.path.join(src,fn),dst)
    def clear(self):
        if self.combat_ev:self.combat_ev.cancel(); self.combat_ev=None
        self.root_box.clear_widgets(); self.enemy_cards=[]
    def bg_image(self,source):
        im=Image(source=source,allow_stretch=True,keep_ratio=False,size_hint=(1,1),pos_hint={'x':0,'y':0}); self.root_box.add_widget(im); return im
    def add_overlay(self,rgba=(.02,.03,.05,.42)):
        w=Widget(); self.root_box.add_widget(w)
        with w.canvas:Color(*rgba); r=Rectangle(pos=w.pos,size=w.size)
        w.bind(pos=lambda *_:setattr(r,'pos',w.pos),size=lambda *_:setattr(r,'size',w.size)); return w
    def btn(self,text,cmd,color=(.12,.18,.25,1),gold=False,**kw):
        b=Button(text=text,font_size=sp(15),bold=True,color=(.98,.91,.72,1) if gold else TEXT,background_normal='',background_down='',background_color=GOLD if gold else color,**kw); b.bind(on_release=lambda *_:cmd()); return b
    def header(self,title,subtitle='',back=None):
        bar=BgBox(orientation='horizontal',padding=dp(8),spacing=dp(8),size_hint=(1,None),height=dp(66),bg=(.03,.05,.075,.98),border=(.48,.35,.16,1));
        if back:bar.add_widget(self.btn('←',back,size_hint=(None,1),width=dp(72)))
        txt=BoxLayout(orientation='vertical'); txt.add_widget(FitLabel(text=title,bold=True,font_size=sp(22),color=(.95,.82,.52,1))); txt.add_widget(FitLabel(text=subtitle,font_size=sp(12),color=MUTED)); bar.add_widget(txt)
        if self.core.player:bar.add_widget(FitLabel(text=self.stats_short(),font_size=sp(12),color=GOLD,size_hint=(None,1),width=dp(310),halign='right'))
        return bar
    def stats_short(self):
        p=self.core.player; return f'Рів. {p.level}   XP {p.xp}/{p.xp_needed()}   💰 {p.gold}   Тріал {p.trial}'
    def popup(self,title,text,buttons=None):
        box=BgBox(orientation='vertical',padding=dp(15),spacing=dp(10),bg=(.06,.08,.12,1)); box.add_widget(FitLabel(text=text,font_size=sp(15),halign='center'))
        pop=Popup(title=title,content=box,size_hint=(.78,.64),auto_dismiss=False,background='')
        row=BoxLayout(size_hint=(1,None),height=dp(54),spacing=dp(8)); box.add_widget(row)
        if buttons:
            for label,fn in buttons:
                row.add_widget(self.btn(label,lambda f=fn:(pop.dismiss(),f())[1] if f else pop.dismiss(),gold='Так' in label or 'Добре' in label or 'Продовжити' in label))
        else:row.add_widget(self.btn('Добре',pop.dismiss,gold=True))
        pop.open(); return pop
    def start_screen(self):
        self.clear(); self.bg_image('assets/ui_bg_city.png'); self.add_overlay((.01,.02,.04,.50))
        panel=BgBox(orientation='vertical',padding=dp(16),spacing=dp(12),size_hint=(.76,.88),pos_hint={'center_x':.5,'center_y':.5},bg=(.025,.04,.065,.94),border=(.57,.41,.18,1)); self.root_box.add_widget(panel)
        panel.add_widget(FitLabel(text='ЕФІРНІ ВИПРОБУВАННЯ',font_size=sp(30),bold=True,color=(.96,.79,.39,1),halign='center',size_hint=(1,.13)))
        panel.add_widget(FitLabel(text='Android • RPG v5.6 • механіки та баланс перенесено з ПК-версії',font_size=sp(14),color=MUTED,halign='center',size_hint=(1,.08)))
        row=BoxLayout(spacing=dp(12)); panel.add_widget(row)
        for cls in ('Воїн','Маг','Монах'):
            card=BgBox(orientation='vertical',padding=dp(8),spacing=dp(6),bg=(.05,.075,.11,.96)); row.add_widget(card)
            card.add_widget(Image(source=f"assets/{ {'Воїн':'hero_warrior','Маг':'hero_mage','Монах':'hero_monk'}[cls] }.png",size_hint=(1,.50)))
            card.add_widget(FitLabel(text=cls,bold=True,font_size=sp(20),halign='center',size_hint=(1,.11),color=GOLD))
            card.add_widget(FitLabel(text=self.core.save_summary(cls),font_size=sp(12),halign='center',size_hint=(1,.12),color=MUTED))
            if self.core.has_save(cls):card.add_widget(self.btn('Продовжити',partial(self.load_class,cls),gold=True,size_hint=(1,.13)))
            else:card.add_widget(Widget(size_hint=(1,.13)))
            card.add_widget(self.btn('Нова гра',partial(self.confirm_new,cls),size_hint=(1,.13)))
    def confirm_new(self,cls):
        if self.core.has_save(cls):self.popup('Нова гра',f'Перезаписати збереження класу «{cls}»?', [('Скасувати',None),('Так, почати',partial(self.new_class,cls))])
        else:self.new_class(cls)
    def new_class(self,cls): self.core.new_game(cls); self.hub()
    def load_class(self,cls): self.core.load_game(cls); self.hub()
    def hub(self):
        self.clear(); self.bg_image('assets/ui_city_concept.png'); self.add_overlay((0,0,0,.10))
        # Right live panel so baked concept stats never lie.
        p=self.core.player; right=BgBox(orientation='vertical',padding=dp(10),spacing=dp(4),size_hint=(.25,.94),pos_hint={'right':.99,'center_y':.5},bg=(.025,.035,.055,.91),border=(.48,.35,.17,1)); self.root_box.add_widget(right)
        right.add_widget(Image(source=self.core.hero_asset(),size_hint=(1,.50)))
        right.add_widget(FitLabel(text=p.cls,bold=True,font_size=sp(22),halign='center',color=GOLD,size_hint=(1,.09)))
        right.add_widget(FitLabel(text=f'Сила: {p.strength}\nЖивучість: {p.vitality}\nБроня: {p.armor} ({p.mitigation*100:.1f}%)\nШвидкість: {p.haste}\nСет: {p.set_count()}/5',font_size=sp(13),color=TEXT,size_hint=(1,.23)))
        right.add_widget(FitLabel(text=self.stats_short(),font_size=sp(12),color=GOLD,halign='center',size_hint=(1,.10)))
        # Graphic menu cards from the approved concept.
        menu=[('city_btn_tavern.png','Таверна',self.tavern),('city_btn_trials.png','Тріали',self.trials),('city_btn_dungeons.png','Підземелля',self.dungeons),('city_btn_inventory.png','Інвентар',self.inventory),('city_btn_abilities.png','Здібності',self.abilities),('city_btn_merchant.png','Торговець',self.merchant),('city_btn_blacksmith.png','Коваль',self.blacksmith),('city_btn_save.png','Зберегти',self.manual_save),('city_btn_exit.png','До класів',self.return_start)]
        grid=GridLayout(cols=2,spacing=dp(7),padding=dp(8),size_hint=(.40,.90),pos_hint={'x':.025,'center_y':.5}); self.root_box.add_widget(grid)
        for img,title,fn in menu:
            b=Button(background_normal='assets/'+img,background_down='assets/'+img,text='',border=(0,0,0,0)); b.bind(on_release=lambda _,f=fn:f()); grid.add_widget(b)
    def manual_save(self): self.core.save_game(); self.popup('Збережено',f'Гру за клас «{self.core.player.cls}» збережено.')
    def return_start(self): self.core.save_game(); self.core.player=None; self.start_screen()
    def screen_shell(self,title,subtitle,back):
        self.clear(); self.bg_image('assets/ui_bg_city.png'); self.add_overlay((.01,.02,.04,.64)); root=BoxLayout(orientation='vertical',padding=dp(10),spacing=dp(8)); self.root_box.add_widget(root); root.add_widget(self.header(title,subtitle,back)); return root
    def scroll_column(self,parent):
        sc=ScrollView(); col=GridLayout(cols=1,spacing=dp(8),padding=dp(6),size_hint_y=None); col.bind(minimum_height=col.setter('height')); sc.add_widget(col); parent.add_widget(sc); return col
    def tavern(self):
        root=self.screen_shell('Таверна «Срібний Кубок»','5 легких стартових квестів',self.hub); col=self.scroll_column(root); quests=['Принести трави алхіміку','Вигнати щурів зі складу','Супроводити торговця','Очистити підвал','Знайти загублений амулет']
        for i,q in enumerate(quests):
            row=BgBox(orientation='horizontal',padding=dp(9),spacing=dp(8),size_hint_y=None,height=dp(74)); row.add_widget(FitLabel(text=f'{SLOT_ICON[SLOTS[i]]}  {q}\n[color=aaaaaa]Нагорода: {SLOTS[i]} + 35 золота[/color]',markup=True)); done=self.core.player.tavern_done[i]; row.add_widget(self.btn('Виконано' if done else 'Виконати',partial(self.finish_tavern,i),gold=not done,size_hint=(None,1),width=dp(150),disabled=done)); col.add_widget(row)
    def finish_tavern(self,i):
        p=self.core.player; p.tavern_done[i]=True; it=self.core.generate_item(1,SLOTS[i],starter=True); p.inventory.append(it); p.gold+=35; self.core.save_game(); self.popup('Нагорода',f'{it.short()}\n{it.stats()}\n+35 золота',[('Добре',self.tavern)])
    def merchant(self):
        root=self.screen_shell('Торговець','3 випадкові предмети приблизно твого тріалу',self.hub); col=self.scroll_column(root)
        for it in [self.core.generate_item(max(1,self.core.player.trial-1)) for _ in range(3)]:
            price=max(45,it.salvage_value()*3); row=BgBox(orientation='horizontal',padding=dp(10),spacing=dp(10),size_hint_y=None,height=dp(88),border=RARITY_COLORS[it.rarity]); row.add_widget(FitLabel(text=f'{RARITY_MARK[it.rarity]} {it.name}\n{it.stats()}',font_size=sp(13),color=RARITY_COLORS[it.rarity])); row.add_widget(self.btn(f'Купити\n{price} 💰',partial(self.buy_item,it,price),gold=True,size_hint=(None,1),width=dp(145))); col.add_widget(row)
    def buy_item(self,it,price):
        if self.core.player.gold<price:self.popup('Не вистачає золота',f'Потрібно {price} золота.'); return
        self.core.player.gold-=price; self.core.player.inventory.append(it); self.core.save_game(); self.popup('Куплено',f'{it.short()} додано в рюкзак.',[('Добре',self.hub)])
    def blacksmith(self):
        root=self.screen_shell('Коваль','+10% до всіх 4 характеристик одягненої речі',self.hub); col=self.scroll_column(root); p=self.core.player
        for slot in SLOTS:
            it=p.equipment.get(slot); row=BgBox(orientation='horizontal',padding=dp(9),spacing=dp(8),size_hint_y=None,height=dp(86));
            if not it:row.add_widget(FitLabel(text=f'{SLOT_ICON[slot]} {slot}: порожньо',color=MUTED)); col.add_widget(row); continue
            cost=max(60,int((it.strength+it.vitality*.2+it.armor*.35+it.haste*4)*1.6)); row.add_widget(FitLabel(text=f'{SLOT_ICON[slot]} {it.name}\n{it.stats()}',font_size=sp(13),color=RARITY_COLORS[it.rarity])); row.add_widget(self.btn(f'Покращити\n{cost} 💰',partial(self.upgrade_item,it,cost),gold=True,size_hint=(None,1),width=dp(155))); col.add_widget(row)
    def upgrade_item(self,it,cost):
        p=self.core.player
        if p.gold<cost:self.popup('Не вистачає золота',f'Потрібно {cost} золота.'); return
        p.gold-=cost; it.strength=max(it.strength+1,round(it.strength*1.10)); it.vitality=max(it.vitality+2,round(it.vitality*1.10)); it.armor=max(it.armor+1,round(it.armor*1.10)); it.haste=max(it.haste+1,round(it.haste*1.10)); it.name += '' if it.name.endswith(' +') else ' +'; p.hp=min(p.hp,p.max_hp); self.core.save_game(); self.blacksmith()
    def inventory(self):
        root=self.screen_shell('Інвентар','Торкнись предмета, щоб одягнути або розібрати',self.hub); body=BoxLayout(spacing=dp(8)); root.add_widget(body); left=BoxLayout(orientation='vertical',spacing=dp(6),size_hint=(.38,1)); body.add_widget(left); p=self.core.player
        hero=BgBox(orientation='vertical',padding=dp(6),spacing=dp(4),size_hint=(1,.54)); hero.add_widget(Image(source=self.core.hero_asset(),size_hint=(1,.62))); hero.add_widget(FitLabel(text=f'{p.cls} • Сет {p.set_count()}/5\nСила {p.strength} • HP {p.max_hp} • Броня {p.armor} • Шв. {p.haste}',font_size=sp(12),halign='center',size_hint=(1,.20))); left.add_widget(hero)
        eq=GridLayout(cols=1,spacing=dp(4),size_hint=(1,.46)); left.add_widget(eq)
        for slot in SLOTS:
            it=p.equipment.get(slot); txt=f'{SLOT_ICON[slot]} {slot}: '+(it.name if it else 'порожньо'); eq.add_widget(self.btn(txt,partial(self.show_item,it,True) if it else lambda:None,color=(.08,.12,.18,1)))
        right=BoxLayout(orientation='vertical',spacing=dp(5)); body.add_widget(right); top=BoxLayout(size_hint=(1,None),height=dp(50),spacing=dp(5)); top.add_widget(FitLabel(text=f'Рюкзак: {len(p.inventory)}',bold=True)); top.add_widget(self.btn('Розібрати все',self.salvage_all,size_hint=(None,1),width=dp(170))); right.add_widget(top); sc=ScrollView(); col=GridLayout(cols=1,spacing=dp(5),size_hint_y=None); col.bind(minimum_height=col.setter('height')); sc.add_widget(col); right.add_widget(sc)
        for it in list(p.inventory):
            txt=f'{RARITY_MARK[it.rarity]} {it.name}  •  {it.slot}  •  Рів. {it.level}\n{it.stats()}'+(f'\n✦ {it.set_name}' if it.set_name else ''); b=self.btn(txt,partial(self.show_item,it,False),color=(.07,.10,.15,1),size_hint_y=None,height=dp(78)); b.halign='left'; col.add_widget(b)
    def show_item(self,it,equipped=False):
        if not it:return
        p=self.core.player; settxt=''
        if it.set_name:
            pieces=p.set_count() if it.set_name==SET_NAMES[p.cls] else 0; settxt=f'\n\n{it.set_name} • {pieces}/5\n'+ '\n'.join(('✓ ' if pieces>=need else '○ ')+f'{need}/5 — {desc}' for need,desc in self.core.class_set_bonus_lines())
        buttons=[]
        if equipped:buttons=[('Зняти',partial(self.unequip,it.slot)),('Закрити',None)]
        else:buttons=[('Одягнути',partial(self.equip,it)),('Розібрати',partial(self.salvage,it)),('Закрити',None)]
        self.popup(it.name,f'{it.slot} • Рів. {it.level} • {it.rarity}\n{it.stats()}{settxt}',buttons)
    def equip(self,it):
        p=self.core.player
        if it not in p.inventory:return
        old=p.equipment.get(it.slot); p.inventory.remove(it)
        if old:p.inventory.append(old)
        p.equipment[it.slot]=it; p.hp=min(p.hp,p.max_hp); self.core.save_game(); self.inventory()
    def unequip(self,slot):
        p=self.core.player; it=p.equipment.get(slot)
        if it:p.inventory.append(it); p.equipment[slot]=None; p.hp=min(p.hp,p.max_hp); self.core.save_game()
        self.inventory()
    def salvage(self,it):
        p=self.core.player
        if it in p.inventory:p.inventory.remove(it); p.gold+=it.salvage_value(); self.core.save_game()
        self.inventory()
    def salvage_all(self):
        p=self.core.player
        if not p.inventory:return
        total=sum(i.salvage_value() for i in p.inventory); n=len(p.inventory); self.popup('Розібрати все?',f'{n} предметів → {total} золота. Одягнені речі НЕ зачіпаються.',[('Скасувати',None),('Так, розібрати',lambda:self._salvage_all_do(total))])
    def _salvage_all_do(self,total):self.core.player.inventory.clear(); self.core.player.gold+=total; self.core.save_game(); self.inventory()
    def abilities(self):
        root=self.screen_shell('Здібності','Прокачуються тільки за золото',self.hub); col=self.scroll_column(root); p=self.core.player
        for i,name in enumerate(self.core.ability_names()):
            lvl=p.abilities[i]; row=BgBox(orientation='horizontal',padding=dp(10),spacing=dp(8),size_hint_y=None,height=dp(110)); row.add_widget(FitLabel(text=f'{i+1}. {name} • Рівень {lvl}/10\n{self.core.ability_desc(i,lvl)}',font_size=sp(13))); cost=self.core.ability_cost(i); row.add_widget(self.btn('MAX' if lvl>=10 else f'Покращити\n{cost} 💰',partial(self.buy_ability,i),gold=lvl<10,size_hint=(None,1),width=dp(160),disabled=lvl>=10)); col.add_widget(row)
    def buy_ability(self,i):
        p=self.core.player
        if p.abilities[i]>=10:return
        cost=self.core.ability_cost(i)
        if p.gold<cost:self.popup('Не вистачає золота',f'Потрібно {cost} золота.'); return
        p.gold-=cost; p.abilities[i]+=1; self.core.save_game(); self.abilities()
    def trials(self):
        root=self.screen_shell('Тріали','XP за вбитих ворогів зберігається навіть при поразці',self.hub); col=self.scroll_column(root); p=self.core.player; start=max(1,p.trial-3)
        for t in range(start,p.trial+1):
            row=BgBox(orientation='horizontal',padding=dp(10),spacing=dp(8),size_hint_y=None,height=dp(88),border=GOLD if t==p.trial else (.25,.31,.4,1)); count=min(7,3+(t-1)//2)+1; row.add_widget(FitLabel(text=f'⚔ Тріал {t}\nВорогів: {count} • бос у кінці • нагорода масштабується',font_size=sp(14),color=GOLD if t==p.trial else TEXT)); row.add_widget(self.btn('Увійти',partial(self.start_trial,t),gold=t==p.trial,size_hint=(None,1),width=dp(150))); col.add_widget(row)
    def dungeons(self):
        root=self.screen_shell('Підземелля','Між хвилями відновлюється тільки 10% max HP',self.hub); col=self.scroll_column(root); p=self.core.player
        for idx,cfg in enumerate(DUNGEONS):
            clears=p.dungeon_clears[idx]; reward=f'✦ СЕТОВА річ: {SET_NAMES[p.cls]}' if cfg.get('set_loot') else f"★ Легендарна річ рівня {cfg['loot_level']}"; row=BgBox(orientation='horizontal',padding=dp(9),spacing=dp(8),size_hint_y=None,height=dp(116),border=PURPLE if cfg.get('set_loot') else GOLD if idx>=5 else (.25,.31,.4,1)); row.add_widget(FitLabel(text=f"{cfg['name']}\n{cfg['subtitle']}\nРеком.: Тріал {cfg['recommended']}+ • Хвиль {len(cfg['trash_waves'])+1} • Перемог {clears}\n{reward} • +{cfg['gold']} золота",font_size=sp(12),color=(.87,.81,1,1) if cfg.get('set_loot') else TEXT)); row.add_widget(self.btn('Увійти',partial(self.start_dungeon,idx),gold=True,size_hint=(None,1),width=dp(145))); col.add_widget(row)
    def start_trial(self,t):self.core.start_trial(t); self.combat_screen()
    def start_dungeon(self,idx):self.core.start_dungeon(idx); self.combat_screen()
    def combat_screen(self):
        self.clear(); self.bg_image('assets/arena_dark.png'); self.add_overlay((.01,.015,.025,.40)); root=BoxLayout(orientation='vertical',padding=dp(7),spacing=dp(5)); self.root_box.add_widget(root)
        self.combat_header=self.header('Бій','Торкнись ворога для вибору цілі',lambda:self.popup('Вийти з бою?','Поточний забіг буде перервано.',[('Скасувати',None),('Вийти',self.hub)])); root.add_widget(self.combat_header)
        arena=BoxLayout(spacing=dp(6),size_hint=(1,.62)); root.add_widget(arena); hero=BgBox(orientation='vertical',padding=dp(4),spacing=dp(2),size_hint=(.20,1),bg=(.03,.05,.08,.90)); arena.add_widget(hero); self.hero_img=Image(source=self.core.hero_asset(),size_hint=(1,.70)); hero.add_widget(self.hero_img); self.hero_hp=FitLabel(font_size=sp(14),bold=True,halign='center',size_hint=(1,.14)); hero.add_widget(self.hero_hp); self.hero_stats=FitLabel(font_size=sp(11),color=MUTED,halign='center',size_hint=(1,.16)); hero.add_widget(self.hero_stats)
        sc=ScrollView(do_scroll_y=False,bar_width=dp(5)); self.enemy_grid=GridLayout(rows=1,spacing=dp(5),padding=dp(2),size_hint_x=None); self.enemy_grid.bind(minimum_width=self.enemy_grid.setter('width')); sc.add_widget(self.enemy_grid); arena.add_widget(sc); self.rebuild_enemy_cards()
        log=BgBox(orientation='horizontal',padding=dp(6),size_hint=(1,.08),bg=(.025,.04,.06,.92)); self.log_lbl=FitLabel(font_size=sp(11),halign='center'); log.add_widget(self.log_lbl); root.add_widget(log)
        actions=BoxLayout(spacing=dp(5),size_hint=(1,.20)); root.add_widget(actions); self.basic_btn=self.btn('⚔ Атака',self.do_basic,gold=True); actions.add_widget(self.basic_btn); self.skill_btns=[]
        for i,n in enumerate(self.core.ability_names()):
            b=self.btn(f'{i+1}. {n}',partial(self.do_skill,i),color=(.12,.18,.26,1)); self.skill_btns.append(b); actions.add_widget(b)
        self.combat_ev=Clock.schedule_interval(self.combat_tick,.10); self.refresh_combat()
    def rebuild_enemy_cards(self):
        self.enemy_grid.clear_widgets(); self.enemy_cards=[]
        for e in self.core.combat['enemies']:
            card=EnemyCard(e,self,size_hint=(None,1),width=dp(145)); self.enemy_cards.append(card); self.enemy_grid.add_widget(card)
    def refresh_combat(self):
        if not self.core.combat:return
        p=self.core.player; c=self.core.combat; now=time.monotonic(); buff=self.core.warrior_armor_buff_value(p.abilities[2]) if p.cls=='Воїн' and now<c['armor_buff_until'] else 0; mit=min(.99,(p.armor+buff)/(p.armor+buff+650.0)); wave=(f"Хвиля {c['wave']+1}/{c['total_waves']} • " if c['mode']=='dungeon' else '')
        self.hero_hp.text=f'❤ {p.hp}/{p.max_hp}'; self.hero_stats.text=f'{wave}Сила {p.strength}\nБроня {int(p.armor+buff)} • {mit*100:.1f}%'; self.log_lbl.text='   •   '.join(c['log'][-2:])
        rem=max(0,c['next_basic']-now); self.basic_btn.text='⚔ Атака\nГОТОВО' if rem<=0 else f'⚔ Атака\n{rem:.1f} с'; self.basic_btn.background_color=GOLD if rem<=0 else (.15,.17,.20,1)
        for i,b in enumerate(self.skill_btns):
            r=max(0,c['cooldowns'][i]-now); b.text=f'{i+1}. {self.core.ability_names()[i]}\n'+('ГОТОВО' if r<=0 else f'{r:.1f} с'); b.background_color=(.12,.24,.19,1) if r<=0 else (.15,.17,.20,1)
        for card in self.enemy_cards:card.refresh()
    def do_basic(self):
        e=self.core.current_target(); status,val=self.core.basic_attack()
        if status=='hit' and e:self.flash_enemy(e)
        self.finish_check(); self.refresh_combat()
    def do_skill(self,i):
        res=self.core.cast_ability(i)
        if res.get('status')=='cooldown':self.core.addlog(f"⏳ {res['name']}: {res['remaining']:.1f} с.")
        elif res.get('status')=='cast':
            for target,kind in res.get('events',[]):
                if target!='hero':self.flash_enemy(target,kind)
                else:self.hero_flash(kind)
        self.finish_check(); self.refresh_combat()
    def flash_enemy(self,e,kind='hit'):
        for card in self.enemy_cards:
            if card.enemy is e:card.flash(PURPLE if kind in ('lightning','petal') else RED); break
    def hero_flash(self,kind='buff'):
        self.hero_img.color=GREEN if kind=='heal' else GOLD; Animation(color=(1,1,1,1),duration=.25).start(self.hero_img)
    def combat_tick(self,dt):
        if not self.core.combat:return
        res=self.core.enemy_tick()
        for e,dmg,kind in res['hits']:
            if kind=='block':self.hero_img.color=(.55,.75,1,1); Animation(color=(1,1,1,1),duration=.18).start(self.hero_img)
            else:self.hero_img.color=RED; Animation(color=(1,1,1,1),duration=.18).start(self.hero_img)
        if res['defeat']:
            self.combat_ev.cancel(); self.combat_ev=None; self.popup('Поразка','Ти загинув. XP за вже вбитих мобів збережено.',[('До міста',self.hub)]); return
        self.finish_check(); self.refresh_combat()
    def finish_check(self):
        if not self.core.combat_finished():return
        result=self.core.resolve_finished_combat()
        if not result:return
        if result['type']=='next_wave':self.rebuild_enemy_cards(); self.hero_flash('heal'); return
        if self.combat_ev:self.combat_ev.cancel(); self.combat_ev=None
        self.results_screen(result)
    def results_screen(self,result):
        c=self.core.combat; self.clear(); self.bg_image('assets/ui_bg_dungeons.png' if result['type']=='dungeon_win' else 'assets/ui_bg_trials.png'); self.add_overlay((.01,.02,.04,.62)); root=BoxLayout(orientation='vertical',padding=dp(12),spacing=dp(8)); self.root_box.add_widget(root); title=DUNGEONS[result['idx']]['name']+' — Перемога' if result['type']=='dungeon_win' else f"Тріал {result['trial']} — Перемога"; root.add_widget(self.header(title,'Нагорода отримана',self.hub)); body=BoxLayout(spacing=dp(10)); root.add_widget(body); left=BgBox(orientation='vertical',padding=dp(12),spacing=dp(5)); body.add_widget(left); elapsed=max(.1,time.monotonic()-c['started_at']); mins=int(elapsed//60); secs=int(elapsed%60); rows=[('Час',f'{mins}:{secs:02d}'),('Вбито',c['kills']),('Нанесено',c['damage_dealt']),('Отримано',c['damage_taken']),('Лікування',c['healing']),('Звичайна атака',c['basic_damage']),('XP',f"+{c['xp_earned']}"),('Золото',f"+{result['gold']}")]
        left.add_widget(FitLabel(text='Бойова статистика',font_size=sp(21),bold=True,color=GOLD,size_hint=(1,.12)))
        for a,b in rows:left.add_widget(FitLabel(text=f'{a}: {b}',font_size=sp(14)))
        right=BgBox(orientation='vertical',padding=dp(12),spacing=dp(5),size_hint=(.45,1)); body.add_widget(right); it=result['reward']; right.add_widget(FitLabel(text='★ ЗДОБИЧ',font_size=sp(20),bold=True,color=GOLD,halign='center',size_hint=(1,.13))); right.add_widget(FitLabel(text=it.name,font_size=sp(18),bold=True,color=RARITY_COLORS[it.rarity],halign='center',size_hint=(1,.16))); right.add_widget(FitLabel(text=f'{it.slot} • Рів. {it.level} • {it.rarity}\n{it.stats()}'+(f'\n\n✦ {it.set_name}' if it.set_name else ''),font_size=sp(13),halign='center')); right.add_widget(self.btn('🎒 Інвентар',self.inventory,gold=True,size_hint=(1,.14))); right.add_widget(self.btn('🏙 До міста',self.hub,size_hint=(1,.14)))

if __name__=='__main__': EtherTrialsApp().run()
