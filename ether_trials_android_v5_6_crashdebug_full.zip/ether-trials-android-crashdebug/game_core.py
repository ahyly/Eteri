import random, json, os, math, time
from dataclasses import dataclass, asdict

CLASSES = {
    'Маг': {'base_strength': 120, 'base_vitality': 1150, 'base_armor': 110, 'attack_range': 'дальня', 'basic_mult': 1.00},
    'Воїн': {'base_strength': 105, 'base_vitality': 1550, 'base_armor': 300, 'attack_range': 'ближня', 'basic_mult': 1.00},
    'Монах': {'base_strength': 115, 'base_vitality': 1350, 'base_armor': 180, 'attack_range': 'ближня', 'basic_mult': 1.00},
}
SLOTS = ['Шолом', 'Нагрудник', 'Зброя', 'Щит', 'Аксесуар']
RARITIES = [('Звичайний',1.0),('Рідкісний',1.18),('Епічний',1.42),('Легендарний',1.75)]
RARITY_MARK={'Звичайний':'●','Рідкісний':'◆','Епічний':'✦','Легендарний':'★'}
SLOT_ICON={'Шолом':'◉','Нагрудник':'▣','Зброя':'⚔','Щит':'⬟','Аксесуар':'✧'}
RARITY_COLORS={'Звичайний':(0.68,0.72,0.78,1),'Рідкісний':(0.45,0.66,1,1),'Епічний':(0.71,0.61,1,1),'Легендарний':(0.95,0.78,0.36,1)}

SET_NAMES = {
    'Воїн':'Комплект Непохитного Судді',
    'Монах':'Комплект Кривавого Лотоса',
    'Маг':'Комплект Володаря Бурі',
}
SET_ITEM_NAMES = {
    'Воїн':{'Шолом':'Вінець Непохитного Судді','Нагрудник':'Лати Непохитного Судді','Зброя':'Клинок Останнього Вироку','Щит':'Егіда Останнього Вироку','Аксесуар':'Печатка Непохитного Судді'},
    'Монах':{'Шолом':'Вінець Кривавого Лотоса','Нагрудник':'Облачення Кривавого Лотоса','Зброя':'Кулаки Кривавого Лотоса','Щит':'Печать Кривавого Лотоса','Аксесуар':'Серце Кривавого Лотоса'},
    'Маг':{'Шолом':'Корона Володаря Бурі','Нагрудник':'Мантія Володаря Бурі','Зброя':'Посох Чотирьох Блискавок','Щит':'Фоліант Грозового Ефіру','Аксесуар':'Око Володаря Бурі'},
}

@dataclass
class Item:
    name: str
    slot: str
    level: int
    rarity: str
    strength: int
    vitality: int
    armor: int
    haste: int
    set_name: str = ''
    def short(self): return f"{self.name} [{self.rarity}]"
    def stats(self): return f"Сила +{self.strength}   Живучість +{self.vitality}   Броня +{self.armor}   Швидкість +{self.haste}"
    def salvage_value(self):
        mult={'Звичайний':1.0,'Рідкісний':1.5,'Епічний':2.4,'Легендарний':4.0}[self.rarity]
        return max(8, int((self.level*8 + self.strength*.35 + self.vitality*.08 + self.armor*.12)*mult))

class Player:
    def __init__(self, cls):
        self.cls=cls; self.level=1; self.xp=0; self.gold=0; self.trial=1
        self.abilities=[1,1,1]; self.equipment={s:None for s in SLOTS}; self.inventory=[]
        self.tavern_done=[False]*5; self.dungeon_clears=[0]*7; self.hp=self.max_hp
    @property
    def core(self): return CLASSES[self.cls]
    def set_count(self):
        wanted=SET_NAMES.get(self.cls,'')
        return sum(1 for i in self.equipment.values() if i and getattr(i,'set_name','')==wanted)
    def has_set_bonus(self,pieces): return self.set_count() >= pieces
    @property
    def base_total_strength(self): return self.core['base_strength']+sum(i.strength if i else 0 for i in self.equipment.values())+(self.level-1)*5
    @property
    def strength(self):
        base=self.base_total_strength
        return int(round(base*1.30)) if self.has_set_bonus(2) else base
    @property
    def vitality(self): return self.core['base_vitality']+sum(i.vitality if i else 0 for i in self.equipment.values())+(self.level-1)*30
    @property
    def armor(self): return self.core['base_armor']+sum(i.armor if i else 0 for i in self.equipment.values())+(self.level-1)*4
    @property
    def haste(self): return sum(i.haste if i else 0 for i in self.equipment.values())
    @property
    def max_hp(self): return self.vitality
    @property
    def mitigation(self): return min(.99, self.armor/(self.armor+650.0))
    @property
    def basic_cd(self): return max(.48, 1.28*(100/(100+self.haste)))
    def xp_needed(self): return 100+self.level*55
    def add_xp(self, amount):
        self.xp += amount; gained=0
        while self.xp >= self.xp_needed():
            self.xp -= self.xp_needed(); self.level += 1; gained += 1
        return gained
    def to_dict(self):
        return {'cls':self.cls,'level':self.level,'xp':self.xp,'gold':self.gold,'trial':self.trial,'abilities':self.abilities,
                'equipment':{k:(asdict(v) if v else None) for k,v in self.equipment.items()},'inventory':[asdict(i) for i in self.inventory],
                'tavern_done':self.tavern_done,'dungeon_clears':self.dungeon_clears,'hp':self.hp}
    @classmethod
    def from_dict(cls,d):
        p=cls(d['cls']); p.level=d.get('level',1); p.xp=d.get('xp',0); p.gold=d.get('gold',0); p.trial=d.get('trial',1)
        p.abilities=list(d.get('abilities',[1,1,1])); p.tavern_done=list(d.get('tavern_done',[False]*5)); p.dungeon_clears=list(d.get('dungeon_clears',[0]*7))
        while len(p.dungeon_clears)<7:p.dungeon_clears.append(0)
        raw_eq=d.get('equipment',{})
        p.equipment={s:(Item(**raw_eq[s]) if raw_eq.get(s) else None) for s in SLOTS}
        p.inventory=[Item(**x) for x in d.get('inventory',[])]; p.hp=min(d.get('hp',p.max_hp),p.max_hp); return p

ENEMY_TYPES={
    'Гнол': {'hp':1.00,'armor':.75,'damage':.85,'cd':2.65,'xp':18,'glyph':'G'},
    'Скелет': {'hp':.85,'armor':1.10,'damage':.75,'cd':3.10,'xp':20,'glyph':'S'},
    'Тінь': {'hp':.72,'armor':.55,'damage':1.05,'cd':3.55,'xp':22,'glyph':'T'},
    'Розбійник': {'hp':.92,'armor':.70,'damage':1.15,'cd':4.00,'xp':24,'glyph':'R'},
    'Проклятий': {'hp':1.18,'armor':1.20,'damage':.90,'cd':4.40,'xp':26,'glyph':'P'},
}

DUNGEONS = [
 {'name':'Забуті катакомби','subtitle':'Перший серйозний крок після стартових тріалів.','recommended':5,'power_trial':6,'trash_waves':[4,5],'boss_adds':1,'enemy_mult':1.12,'loot_level':8,'loot_mult':2.35,'gold':320,'boss_name':'Кістяний Прелат','boss_glyph':'☠','loot_prefix':'Катакомб'},
 {'name':'Попелястий бастіон','subtitle':'Довший забіг: вороги витриваліші й б’ють значно болючіше.','recommended':10,'power_trial':11,'trash_waves':[5,6,6],'boss_adds':2,'enemy_mult':1.20,'loot_level':14,'loot_mult':2.65,'gold':650,'boss_name':'Воєвода Попелу','boss_glyph':'♜','loot_prefix':'Бастіону'},
 {'name':'Ефірна цитадель','subtitle':'Ендґейм-підземелля: багато хвиль, сильний бос і найкращий лут.','recommended':16,'power_trial':18,'trash_waves':[6,7,7,8],'boss_adds':3,'enemy_mult':1.30,'loot_level':22,'loot_mult':3.00,'gold':1200,'boss_name':'Архонт Ефіру','boss_glyph':'✦','loot_prefix':'Цитаделі'},
 {'name':'Безодня Забутих','subtitle':'Перший справжній ендґейм. Розраховано на героя, повністю одягненого в легендарки Ефірної цитаделі.','recommended':24,'power_trial':32,'trash_waves':[6,7,8,8],'boss_adds':3,'enemy_mult':1.0,'hp_mult':4.8,'armor_mult':3.0,'damage_mult':4.2,'boss_hp_mult':6.4,'boss_armor_mult':3.6,'boss_damage_mult':4.8,'loot_level':32,'loot_mult':4.35,'gold':2600,'boss_name':'Пожирач Забутих','boss_glyph':'Ω','loot_prefix':'Безодні'},
 {'name':'Храм Падших Богів','subtitle':'Без повного комплекту Безодні сюди краще не заходити. Вороги переживають потужні прокасти й карають за затяжний бій.','recommended':38,'power_trial':48,'trash_waves':[7,8,8,9,9],'boss_adds':4,'enemy_mult':1.0,'hp_mult':7.5,'armor_mult':4.6,'damage_mult':6.5,'boss_hp_mult':10.0,'boss_armor_mult':5.4,'boss_damage_mult':7.3,'loot_level':46,'loot_mult':6.45,'gold':5200,'boss_name':'Аватар Падшого Бога','boss_glyph':'Ψ','loot_prefix':'Падших Богів'},
 {'name':'Трон Кінця','subtitle':'Найскладніше підземелля. Орієнтир — повний легендарний комплект Храму та добре прокачані здібності.','recommended':55,'power_trial':68,'trash_waves':[8,9,9,10,10,11],'boss_adds':5,'enemy_mult':1.0,'hp_mult':11.5,'armor_mult':7.0,'damage_mult':9.8,'boss_hp_mult':16.0,'boss_armor_mult':8.2,'boss_damage_mult':11.0,'loot_level':64,'loot_mult':9.30,'gold':10000,'boss_name':'Володар Кінця','boss_glyph':'♛','loot_prefix':'Трону Кінця'},
 {'name':'Собор Вічної Ночі','subtitle':'Новий найвищий ендґейм. Розраховано щонайменше на повний легендарний комплект Трону Кінця. Саме тут падає класовий сет.','recommended':80,'power_trial':92,'trash_waves':[9,10,10,11,11,12,12],'boss_adds':6,'enemy_mult':1.0,'hp_mult':20.0,'armor_mult':11.0,'damage_mult':15.5,'boss_hp_mult':30.0,'boss_armor_mult':13.0,'boss_damage_mult':18.0,'loot_level':84,'loot_mult':13.80,'gold':18000,'boss_name':'Первозданний Суддя','boss_glyph':'✠','loot_prefix':'Вічної Ночі','set_loot':True},
]
DUNGEON_ITEM_NAMES = {
 0:{'Шолом':'Корона Катакомб','Нагрудник':'Панцир Мовчазних','Зброя':'Релікварій Некрополя','Щит':'Щит Гробниці','Аксесуар':'Печатка Прелата'},
 1:{'Шолом':'Шолом Попелястого Легіону','Нагрудник':'Кіраса Вічного Жару','Зброя':'Зброя Воєводи','Щит':'Бастіонний Щит','Аксесуар':'Серце Жар-Печі'},
 2:{'Шолом':'Вінець Архонта','Нагрудник':'Ефірна Кіраса','Зброя':'Зброя Розлому','Щит':'Щит Цитаделі','Аксесуар':'Око Ефіру'},
 3:{'Шолом':'Корона Безодні','Нагрудник':'Обладунок Забутих','Зброя':'Ікло Безодні','Щит':'Бар’єр Порожнечі','Аксесуар':'Серце Пожирача'},
 4:{'Шолом':'Лик Падшого Бога','Нагрудник':'Божественна Руїна','Зброя':'Кара Богів','Щит':'Егіда Падіння','Аксесуар':'Око Забутого Бога'},
 5:{'Шолом':'Вінець Кінця','Нагрудник':'Обладунок Останньої Епохи','Зброя':'Кінець Світу','Щит':'Останній Бастіон','Аксесуар':'Печатка Володаря'},
 6:{'Шолом':'Сетовий шолом','Нагрудник':'Сетовий нагрудник','Зброя':'Сетова зброя','Щит':'Сетовий щит','Аксесуар':'Сетовий аксесуар'},
}

class Enemy:
    def __init__(self, trial, idx, boss=False):
        self.boss=boss; scale=1+(trial-1)*.12
        if boss:
            self.kind='Вартовий'; self.name=f'Вартовий тріалу {trial}'; self.glyph='B'; self.max_hp=int(720*scale); self.armor=int(105*scale); self.damage=int(48*scale); self.attack_cd=4.8; self.xp=65+trial*8
        else:
            self.kind=random.choice(list(ENEMY_TYPES)); cfg=ENEMY_TYPES[self.kind]; self.glyph=cfg['glyph']; self.name=f'{self.kind} {idx+1}'; self.max_hp=int(225*scale*cfg['hp']*random.uniform(.94,1.06)); self.armor=int(48*scale*cfg['armor']); self.damage=int(28*scale*cfg['damage']); self.attack_cd=cfg['cd']; self.xp=int(cfg['xp']*scale)
        self.hp=self.max_hp; self.next_attack=time.monotonic()+random.uniform(.75,self.attack_cd); self.xp_awarded=False
    @property
    def mitigation(self): return min(.86,self.armor/(self.armor+480.0))

class GameCore:
    def __init__(self, save_dir):
        self.save_dir=save_dir; os.makedirs(save_dir,exist_ok=True); self.player=None; self.combat=None
    def save_path(self,cls): return os.path.join(self.save_dir,{'Маг':'save_mage.json','Воїн':'save_warrior.json','Монах':'save_monk.json'}[cls])
    def has_save(self,cls): return os.path.exists(self.save_path(cls))
    def save_summary(self,cls):
        try:
            with open(self.save_path(cls),'r',encoding='utf-8') as f:d=json.load(f)
            return f"Рів. {d.get('level',1)} • Тріал {d.get('trial',1)} • {d.get('gold',0)} золота"
        except Exception:return 'Немає збереження'
    def save_game(self):
        if not self.player:return
        with open(self.save_path(self.player.cls),'w',encoding='utf-8') as f:json.dump(self.player.to_dict(),f,ensure_ascii=False,indent=2)
    def load_game(self,cls):
        with open(self.save_path(cls),'r',encoding='utf-8') as f:self.player=Player.from_dict(json.load(f))
        return self.player
    def new_game(self,cls): self.player=Player(cls); self.save_game(); return self.player
    def generate_item(self,level,slot=None,starter=False):
        slot=slot or random.choice(SLOTS)
        if starter: rarity,mult='Звичайний',.72
        else:
            r=random.random(); rarity,mult=RARITIES[0] if r<.58 else RARITIES[1] if r<.84 else RARITIES[2] if r<.97 else RARITIES[3]
        base=max(1,level); names={'Шолом':'Шолом','Нагрудник':'Кіраса','Зброя':'Зброя','Щит':'Щит','Аксесуар':'Талісман'}; prefix='Тавернний' if starter else random.choice(['Ефірний','Стародавній','Загартований','Тіньовий','Рунічний'])
        strv=max(1,int(random.randint(7,13)*base*.48*mult)); vit=max(1,int(random.randint(28,48)*base*.62*mult)); arm=max(1,int(random.randint(10,20)*base*.60*mult)); haste=max(1,int(random.randint(1,4)*math.sqrt(base)*mult))
        return Item(f'{prefix} {names[slot]}',slot,level,rarity,strv,vit,arm,haste)
    def generate_dungeon_item(self,dungeon_idx):
        cfg=DUNGEONS[dungeon_idx]; clears=self.player.dungeon_clears[dungeon_idx] if self.player and dungeon_idx<len(self.player.dungeon_clears) else 0
        cycle,pos=divmod(clears,len(SLOTS)); class_seed=sum((i+1)*ord(ch) for i,ch in enumerate(self.player.cls if self.player else '')); bag=list(SLOTS); rng=random.Random((dungeon_idx+1)*1000003+cycle*9176+class_seed); rng.shuffle(bag); slot=bag[pos]
        level=cfg['loot_level']; mult=cfg['loot_mult']; strv=max(1,int(random.randint(8,14)*level*.48*mult)); vit=max(1,int(random.randint(32,52)*level*.62*mult)); arm=max(1,int(random.randint(12,22)*level*.60*mult)); haste=max(1,int(random.randint(2,5)*math.sqrt(level)*mult))
        if cfg.get('set_loot'): set_name=SET_NAMES[self.player.cls]; name=SET_ITEM_NAMES[self.player.cls][slot]
        else: set_name=''; name=DUNGEON_ITEM_NAMES[dungeon_idx][slot]
        return Item(name,slot,level,'Легендарний',strv,vit,arm,haste,set_name)
    def ability_names(self): return {'Маг':['Вибух ефіру','Гром і молнія','Щит мани'],'Воїн':['Талісман доблесті','Гром і молнія','Броня богів'],'Монах':['Кривавий цвіт','Гром і молнія','Листок лотоса']}[self.player.cls]
    def lerp(self,a,b,lvl): return a+(b-a)*(lvl-1)/9
    def ability_cd_value(self,i,lvl=None):
        lvl=lvl or self.player.abilities[i]; c=self.player.cls
        if c=='Маг': return self.lerp(8,7,lvl) if i==0 else 6.0
        if c=='Воїн': return 5.0 if i==0 else 6.0
        return self.lerp(6,4,lvl) if i==0 else (6.0 if i==1 else 3.0)
    def ability_cost(self,idx):
        lvl=self.player.abilities[idx]; return int(70+lvl*45+(lvl-1)**2*14)
    def warrior_armor_buff_value(self,lvl=None):
        lvl=lvl or self.player.abilities[2]
        if self.player.cls=='Воїн' and self.player.has_set_bonus(3):return 5000
        return self.lerp(400,1500,lvl)
    def class_set_bonus_lines(self,cls=None):
        cls=cls or self.player.cls
        if cls=='Воїн':return [(2,'+30% до загальної сили'),(3,'Броня богів: 5000 броні замість 1500 + лікування 10% максимального HP'),(5,'Талісман доблесті повністю ігнорує броню ворогів')]
        if cls=='Монах':return [(2,'+30% до загальної сили'),(3,'Кривавий цвіт: +3 додаткові цілі'),(5,'Кривавий цвіт: +200 процентних пунктів до урону')]
        return [(2,'+30% до загальної сили'),(3,'Гром і молнія: 4 удари; кожен наступний слабший на 25%'),(5,'Гром і молнія повністю ігнорує броню ворогів')]
    def ability_desc(self,idx,lvl):
        c=self.player.cls
        if c=='Маг':
            if idx==0:return f'Загальний пул = 6 × {self.lerp(110,250,lvl):.0f}% сили. Ділиться між максимум 6 живими цілями. CD {self.lerp(8,7,lvl):.1f} с.'
            if idx==1:return f'Вибрана ціль: {self.lerp(300,1100,lvl):.0f}% сили. CD 6 с.'+(' СЕТ 3/5: 4 удари 100/75/50/25%.' if self.player.has_set_bonus(3) else '')+(' СЕТ 5/5: ігнорує броню.' if self.player.has_set_bonus(5) else '')
            return f'Повна невразливість {self.lerp(2,8,lvl):.1f} с + лікування {self.lerp(10,50,lvl):.0f}% сили. CD 6 с.'
        if c=='Воїн':
            if idx==0:return f'Усі вороги: {self.lerp(105,130,lvl):.0f}% сили + {self.lerp(10,25,lvl):.0f}% від ЧИСЛОВОЇ броні. CD 5 с.'+(' СЕТ 5/5: ігнорує броню.' if self.player.has_set_bonus(5) else '')
            if idx==1:return f'Вибрана ціль: {self.lerp(300,1100,lvl):.0f}% сили. CD 6 с.'
            return f'+{self.warrior_armor_buff_value(lvl):.0f} числової броні на 4 с. CD 6 с.'+(' + лікування 10% максимального HP.' if self.player.has_set_bonus(3) else '')
        if idx==0:return f'{round(self.lerp(4,8,lvl))+(3 if self.player.has_set_bonus(3) else 0)} цілей, ігнорує броню: {self.lerp(110,200,lvl)+(200 if self.player.has_set_bonus(5) else 0):.0f}% сили. CD {self.lerp(6,4,lvl):.1f} с.'
        if idx==1:return f'Вибрана ціль: {self.lerp(300,1100,lvl):.0f}% сили. CD 6 с.'
        return f'Лікує на {self.lerp(10,100,lvl):.0f}% сили. CD 3 с.'
    def character_visual_tier(self,p=None):
        p=p or self.player; items=[it for it in p.equipment.values() if it]
        if not items:return 0
        score=0
        for it in items:score += {'Звичайний':0,'Рідкісний':1,'Епічний':2,'Легендарний':4}.get(it.rarity,0)+(1 if it.level>=22 else 0)+(2 if it.level>=46 else 0)+(2 if it.level>=64 else 0)
        avg=score/max(1,len(items)); return 3 if avg>=7 else (2 if avg>=5 else (1 if avg>=2 else 0))
    def hero_asset(self):
        base={'Воїн':'hero_warrior','Маг':'hero_mage','Монах':'hero_monk'}[self.player.cls]; tier=self.character_visual_tier(); return f'assets/{base}.png' if tier==0 else f'assets/{base}_tier{tier}.png'
    def enemy_asset(self,e):
        if e.boss:return 'assets/enemy_boss.png'
        key={'Скелет':'enemy_skeleton','Тінь':'enemy_shadow','Гнол':'enemy_gnoll','Проклятий':'enemy_cursed','Розбійник':'enemy_cursed'}.get(e.kind,'enemy_cursed')
        if e.kind in ('Проклятий','Розбійник'):
            try:key='enemy_cursed2' if int(e.name.rsplit(' ',1)[-1])%2==0 else 'enemy_cursed'
            except Exception:pass
        return f'assets/{key}.png'
    def make_dungeon_wave(self,dungeon_idx,wave_idx):
        cfg=DUNGEONS[dungeon_idx]; final_wave=wave_idx>=len(cfg['trash_waves']); enemies=[]
        if final_wave:
            boss=Enemy(cfg['power_trial'],0,boss=True); boss.name=cfg['boss_name']; boss.glyph=cfg['boss_glyph']; boss.max_hp=int(boss.max_hp*cfg.get('boss_hp_mult',cfg['enemy_mult']*1.35)); boss.hp=boss.max_hp; boss.armor=int(boss.armor*cfg.get('boss_armor_mult',cfg['enemy_mult']*1.12)); boss.damage=int(boss.damage*cfg.get('boss_damage_mult',cfg['enemy_mult']*1.12)); boss.xp=int(boss.xp*1.8); enemies.append(boss)
            for i in range(cfg['boss_adds']):
                e=Enemy(cfg['power_trial'],i+1); e.max_hp=int(e.max_hp*cfg.get('hp_mult',cfg['enemy_mult'])); e.hp=e.max_hp; e.armor=int(e.armor*cfg.get('armor_mult',cfg['enemy_mult'])); e.damage=int(e.damage*cfg.get('damage_mult',cfg['enemy_mult'])); e.xp=int(e.xp*1.35); enemies.append(e)
        else:
            count=cfg['trash_waves'][wave_idx]
            for i in range(count):
                e=Enemy(cfg['power_trial'],i); wave_mult=1.0+wave_idx*.08; e.max_hp=int(e.max_hp*cfg.get('hp_mult',cfg['enemy_mult'])*wave_mult); e.hp=e.max_hp; e.armor=int(e.armor*cfg.get('armor_mult',cfg['enemy_mult'])*wave_mult); e.damage=int(e.damage*cfg.get('damage_mult',cfg['enemy_mult'])*wave_mult); e.xp=int(e.xp*1.25); enemies.append(e)
        return enemies
    def start_trial(self,t):
        p=self.player; p.hp=p.max_hp; count=min(7,3+(t-1)//2); enemies=[Enemy(t,i) for i in range(count)]+[Enemy(t,count,boss=True)]; now=time.monotonic(); self.combat={'mode':'trial','trial':t,'enemies':enemies,'target':enemies[0],'next_basic':now,'cooldowns':[now]*3,'invuln_until':0,'armor_buff_until':0,'log':['Тріал почався.'],'won':False,'kills':0,'xp_earned':0,'damage_dealt':0,'damage_taken':0,'healing':0,'ability_damage':[0,0,0],'basic_damage':0,'started_at':now}; return self.combat
    def start_dungeon(self,idx):
        p=self.player; p.hp=p.max_hp; cfg=DUNGEONS[idx]; now=time.monotonic(); enemies=self.make_dungeon_wave(idx,0); self.combat={'mode':'dungeon','dungeon_idx':idx,'dungeon_name':cfg['name'],'wave':0,'total_waves':len(cfg['trash_waves'])+1,'enemies':enemies,'target':enemies[0],'next_basic':now,'cooldowns':[now]*3,'invuln_until':0,'armor_buff_until':0,'log':[f"Підземелля почалося. Хвиля 1/{len(cfg['trash_waves'])+1}."],'won':False,'kills':0,'xp_earned':0,'damage_dealt':0,'damage_taken':0,'healing':0,'ability_damage':[0,0,0],'basic_damage':0,'started_at':now}; return self.combat
    def alive(self): return [e for e in self.combat['enemies'] if e.hp>0]
    def current_target(self):
        if self.combat.get('target') in self.alive():return self.combat['target']
        alive=self.alive(); self.combat['target']=alive[0] if alive else None; return self.combat['target']
    def select_enemy(self,e):
        if e.hp>0:self.combat['target']=e
    def addlog(self,s):self.combat['log'].append(s); self.combat['log']=self.combat['log'][-9:]
    def award_kill_if_needed(self,e):
        if e.hp<=0 and not e.xp_awarded:
            e.xp_awarded=True; gained=self.player.add_xp(e.xp); self.combat['kills']+=1; self.combat['xp_earned']+=e.xp; self.addlog(f'☠ {e.name}: +{e.xp} XP.'+(f' Рівень +{gained}!' if gained else '')); self.save_game()
    def deal(self,e,raw,ignore_armor=False,source=None):
        dmg=max(1,int(raw*(1 if ignore_armor else 1-e.mitigation))); e.hp=max(0,e.hp-dmg); c=self.combat; c['damage_dealt']+=dmg
        if source=='basic':c['basic_damage']+=dmg
        elif isinstance(source,int) and 0<=source<3:c['ability_damage'][source]+=dmg
        self.award_kill_if_needed(e); return dmg
    def basic_attack(self):
        if not self.combat or self.combat.get('won'):return ('none',0)
        now=time.monotonic(); c=self.combat
        if now<c['next_basic']:return ('cooldown',c['next_basic']-now)
        e=self.current_target()
        if not e:return ('none',0)
        dmg=self.deal(e,self.player.strength*self.player.core['basic_mult'],source='basic'); c['next_basic']=now+self.player.basic_cd; self.addlog(f'⚔ Ти → {e.name}: {dmg}.'); return ('hit',dmg)
    def cast_ability(self,i):
        if not self.combat or self.combat.get('won') or i not in (0,1,2) or not self.alive():return {'status':'none'}
        c=self.combat; now=time.monotonic(); p=self.player; lvl=p.abilities[i]; name=self.ability_names()[i]
        if now<c['cooldowns'][i]:return {'status':'cooldown','remaining':c['cooldowns'][i]-now,'name':name}
        events=[]
        if p.cls=='Маг':
            if i==0:
                targets=self.alive()[:6]; pool=p.strength*self.lerp(1.10,2.50,lvl)*6; each=pool/len(targets); total=sum(self.deal(e,each,source=i) for e in targets); c['cooldowns'][i]=now+self.lerp(8,7,lvl); events=[(e,'hit') for e in targets]; self.addlog(f'✦ {name}: {total} сумарно по {len(targets)} цілях.')
            elif i==1:
                base_raw=p.strength*self.lerp(3,11,lvl)
                if p.has_set_bonus(3):
                    alive_now=self.alive(); first=self.current_target(); ordered=([first] if first else [])+[e for e in alive_now if e is not first]; total=0
                    for k,mult in enumerate((1.00,.75,.50,.25)):
                        living=[e for e in ordered if e.hp>0]
                        if not living:break
                        target=(ordered[k] if k<len(ordered) and ordered[k].hp>0 else living[k%len(living)]); total+=self.deal(target,base_raw*mult,p.has_set_bonus(5),source=i); events.append((target,'lightning'))
                    c['cooldowns'][i]=now+6; self.addlog(f'⚡ {name}: 4 удари, {total} сумарно.')
                else:
                    e=self.current_target(); dmg=self.deal(e,base_raw,source=i); c['cooldowns'][i]=now+6; events=[(e,'lightning')]; self.addlog(f'⚡ {name} → {e.name}: {dmg}.')
            else:
                heal=int(p.strength*self.lerp(.10,.50,lvl)); actual=min(heal,p.max_hp-p.hp); p.hp=min(p.max_hp,p.hp+heal); c['healing']+=actual; c['invuln_until']=now+self.lerp(2,8,lvl); c['cooldowns'][i]=now+6; self.addlog(f'◈ {name}: щит активний, +{actual} HP.'); events=[('hero','heal')]
        elif p.cls=='Воїн':
            active_armor=p.armor+(self.warrior_armor_buff_value(p.abilities[2]) if now<c['armor_buff_until'] else 0)
            if i==0:
                raw=p.strength*self.lerp(1.05,1.30,lvl)+active_armor*self.lerp(.10,.25,lvl); targets=list(self.alive()); total=sum(self.deal(e,raw,p.has_set_bonus(5),source=i) for e in targets); c['cooldowns'][i]=now+5; events=[(e,'wave') for e in targets]; self.addlog(f'✹ {name}: {total} сумарно. Броня: {active_armor:.0f}.')
            elif i==1:
                e=self.current_target(); dmg=self.deal(e,p.strength*self.lerp(3,11,lvl),source=i); c['cooldowns'][i]=now+6; events=[(e,'lightning')]; self.addlog(f'⚡ {name} → {e.name}: {dmg}.')
            else:
                bonus=self.warrior_armor_buff_value(lvl); c['armor_buff_until']=now+4; c['cooldowns'][i]=now+6
                if p.has_set_bonus(3):
                    heal=max(1,int(p.max_hp*.10)); actual=min(heal,p.max_hp-p.hp); p.hp=min(p.max_hp,p.hp+heal); c['healing']+=actual; self.addlog(f'⬟ {name}: +{bonus:.0f} броні та +{actual} HP.')
                else:self.addlog(f'⬟ {name}: +{bonus:.0f} броні на 4 с.')
                events=[('hero','buff')]
        else:
            if i==0:
                cnt=round(self.lerp(4,8,lvl))+(3 if p.has_set_bonus(3) else 0); targets=self.alive()[:cnt]; mult=self.lerp(1.10,2.00,lvl)+(2.00 if p.has_set_bonus(5) else 0.0); raw=p.strength*mult; total=sum(self.deal(e,raw,True,source=i) for e in targets); c['cooldowns'][i]=now+self.lerp(6,4,lvl); events=[(e,'petal') for e in targets]; self.addlog(f'❀ {name}: {total} сумарно по {len(targets)} цілях.')
            elif i==1:
                e=self.current_target(); dmg=self.deal(e,p.strength*self.lerp(3,11,lvl),source=i); c['cooldowns'][i]=now+6; events=[(e,'lightning')]; self.addlog(f'⚡ {name} → {e.name}: {dmg}.')
            else:
                heal=int(p.strength*self.lerp(.10,1.00,lvl)); actual=min(heal,p.max_hp-p.hp); p.hp=min(p.max_hp,p.hp+heal); c['healing']+=actual; c['cooldowns'][i]=now+3; self.addlog(f'❧ {name}: +{actual} HP.'); events=[('hero','heal')]
        return {'status':'cast','name':name,'events':events}
    def enemy_tick(self):
        if not self.combat or self.combat.get('won'):return {'defeat':False,'hits':[]}
        now=time.monotonic(); p=self.player; hits=[]
        for e in list(self.alive()):
            if now>=e.next_attack:
                e.next_attack=now+e.attack_cd+random.uniform(-.18,.22)
                if now<c_or_zero(self.combat,'invuln_until'):
                    hits.append((e,0,'block')); self.addlog(f'🛡 {e.name}: БЛОК.')
                else:
                    active_armor=p.armor+(self.warrior_armor_buff_value(p.abilities[2]) if p.cls=='Воїн' and now<c_or_zero(self.combat,'armor_buff_until') else 0); mit=min(.99,active_armor/(active_armor+650.0)); dmg=max(1,int(e.damage*(1-mit))); p.hp=max(0,p.hp-dmg); self.combat['damage_taken']+=dmg; hits.append((e,dmg,'hit')); self.addlog(f'🔻 {e.name} → тобі {dmg}.')
                    if p.hp<=0:self.save_game(); return {'defeat':True,'hits':hits}
        return {'defeat':False,'hits':hits}
    def combat_finished(self):return bool(self.combat and not self.alive())
    def resolve_finished_combat(self):
        if not self.combat_finished():return None
        c=self.combat
        if c['mode']=='dungeon':
            idx=c['dungeon_idx']; cfg=DUNGEONS[idx]
            if c['wave']+1<c['total_waves']:
                c['wave']+=1; heal=max(1,int(self.player.max_hp*.10)); actual=min(heal,self.player.max_hp-self.player.hp); self.player.hp+=actual; c['healing']+=actual; c['enemies']=self.make_dungeon_wave(idx,c['wave']); c['target']=c['enemies'][0]; self.addlog(f"Хвиля {c['wave']+1}/{c['total_waves']}. +{actual} HP."); return {'type':'next_wave','heal':actual}
            c['won']=True; reward=self.generate_dungeon_item(idx); self.player.inventory.append(reward); self.player.gold+=cfg['gold']; self.player.dungeon_clears[idx]+=1; self.player.hp=self.player.max_hp; self.save_game(); return {'type':'dungeon_win','reward':reward,'gold':cfg['gold'],'idx':idx}
        c['won']=True; t=c['trial']; reward=self.generate_item(t); self.player.inventory.append(reward); gold=55+t*12; self.player.gold+=gold
        if t>=self.player.trial:self.player.trial=t+1
        self.player.hp=self.player.max_hp; self.save_game(); return {'type':'trial_win','reward':reward,'gold':gold,'trial':t}

def c_or_zero(c,key):return c.get(key,0)
