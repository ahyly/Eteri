[app]
title = Ефірні Випробування
package.name = ethertrials
package.domain = org.ethertrials
source.dir = .
source.include_exts = py,png,jpg,jpeg,json,atlas,ttf,md
source.include_patterns = assets/*,default_saves/*
version = 5.6.0
requirements = python3==3.11.14,hostpython3==3.11.14,kivy
orientation = landscape
fullscreen = 1
icon.filename = assets/hero_mage.png
android.api = 35
android.minapi = 24
android.archs = arm64-v8a
android.accept_sdk_license = True
android.private_storage = True

[buildozer]
log_level = 2
warn_on_root = 1
