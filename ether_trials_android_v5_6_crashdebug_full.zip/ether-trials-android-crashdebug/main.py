__version__ = '5.6.0'
"""Android bootstrap for Ефірні Випробування.

If the real application crashes during import/startup, keep a tiny Kivy process alive
and show the traceback on screen instead of silently returning to the launcher.
"""
import os
import traceback


def _save_traceback(text):
    paths = []
    # App-private location (always the safest writable place on Android).
    try:
        from kivy.app import App
        app = App.get_running_app()
        if app and getattr(app, 'user_data_dir', None):
            paths.append(os.path.join(app.user_data_dir, 'crashlog.txt'))
    except Exception:
        pass
    # python-for-android normally exposes ANDROID_PRIVATE.
    private = os.environ.get('ANDROID_PRIVATE')
    if private:
        paths.append(os.path.join(private, 'crashlog.txt'))
    # Best-effort shared Downloads copy. It may be blocked by scoped storage;
    # failure here is harmless because the traceback is also shown on screen.
    ext = os.environ.get('EXTERNAL_STORAGE')
    if ext:
        paths.append(os.path.join(ext, 'Download', 'ether_trials_crashlog.txt'))

    for path in paths:
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, 'w', encoding='utf-8') as f:
                f.write(text)
        except Exception:
            pass


def _show_crash(text):
    _save_traceback(text)
    try:
        from kivy.app import App
        from kivy.core.window import Window
        from kivy.metrics import dp, sp
        from kivy.uix.boxlayout import BoxLayout
        from kivy.uix.label import Label
        from kivy.uix.scrollview import ScrollView
        from kivy.uix.button import Button

        class CrashScreenApp(App):
            title = 'Ефірні Випробування — помилка запуску'
            def build(self):
                Window.clearcolor = (0.04, 0.04, 0.05, 1)
                root = BoxLayout(orientation='vertical', padding=dp(12), spacing=dp(8))
                root.add_widget(Label(
                    text='ПОМИЛКА ЗАПУСКУ\nЗроби скрін нижнього тексту і надішли його мені.',
                    size_hint_y=None, height=dp(90), font_size=sp(20), bold=True,
                    color=(1, .45, .35, 1), halign='center', valign='middle',
                    text_size=(Window.width - dp(24), None)))
                scroll = ScrollView()
                label = Label(
                    text=text, size_hint_y=None, font_size=sp(12),
                    color=(.95, .95, .95, 1), halign='left', valign='top')
                label.bind(width=lambda w, v: setattr(w, 'text_size', (v, None)))
                label.bind(texture_size=lambda w, v: setattr(w, 'height', max(v[1] + dp(20), scroll.height)))
                scroll.add_widget(label)
                root.add_widget(scroll)
                btn = Button(text='Закрити', size_hint_y=None, height=dp(52))
                btn.bind(on_release=lambda *_: self.stop())
                root.add_widget(btn)
                return root

        CrashScreenApp().run()
    except BaseException:
        # At this point Kivy itself could not display the diagnostic screen.
        # Print both errors for logcat.
        print(text)
        print('CRASH SCREEN FAILED:')
        traceback.print_exc()


try:
    from app_main import run_app
    run_app()
except BaseException:
    tb = traceback.format_exc()
    _show_crash(tb)
